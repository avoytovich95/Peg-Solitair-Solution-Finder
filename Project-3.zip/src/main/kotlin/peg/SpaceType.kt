package peg

enum class SpaceType {
  PEG,
  HOLE,
  BLOCK
}