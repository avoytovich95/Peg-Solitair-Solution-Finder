package peg

enum class Direction {
  NORTH,
  WEST,
  SOUTH,
  EAST
}